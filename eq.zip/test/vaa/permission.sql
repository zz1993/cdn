/*
Navicat MySQL Data Transfer

Source Server         : baixun_cdn_test
Source Server Version : 80017
Source Host           : 118.31.108.209:3306
Source Database       : baixun_cdn_test

Target Server Type    : MYSQL
Target Server Version : 80017
File Encoding         : 65001

Date: 2019-09-18 15:23:34
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for permission
-- ----------------------------
DROP TABLE IF EXISTS `permission`;
CREATE TABLE `permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '菜单名称',
  `pid` int(11) DEFAULT NULL COMMENT '父菜单id',
  `zindex` int(2) DEFAULT NULL COMMENT '菜单排序',
  `istype` int(1) DEFAULT NULL COMMENT '权限分类（0 菜单；1 功能）',
  `descpt` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '描述',
  `code` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '菜单编号',
  `icon` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '菜单图标名称',
  `page` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '菜单url',
  `insert_time` datetime DEFAULT NULL COMMENT '添加时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of permission
-- ----------------------------
INSERT INTO `permission` VALUES ('1', '系统管理', '0', '999', '0', '系统管理', 'system', '', '/', '2017-12-20 16:22:43', '2019-07-30 14:23:26');
INSERT INTO `permission` VALUES ('2', '用户管理', '1', '1100', '0', '用户管理', 'usermanage', '', '/user/userList', '2017-12-20 16:27:03', '2018-01-09 19:26:30');
INSERT INTO `permission` VALUES ('3', '角色管理', '1', '1200', '0', '角色管理', 'rolemanage', '', '/auth/roleManage', '2017-12-20 16:27:03', '2018-01-09 19:26:42');
INSERT INTO `permission` VALUES ('4', '权限管理', '1', '1300', '0', '权限管理', 'permmanage', null, '/auth/permList', '2017-12-30 19:17:32', '2018-01-09 19:26:48');
INSERT INTO `permission` VALUES ('5', 'CDN管理', '0', '300', '0', '商品管理', 'nginx', null, '/', '2017-12-30 19:17:50', '2019-07-31 10:27:27');
INSERT INTO `permission` VALUES ('13', '节点列表', '5', '3100', '0', '节点列表', 'nginx', null, '/nginx/nodeList', '2018-01-09 19:33:53', '2019-06-25 10:00:18');
INSERT INTO `permission` VALUES ('14', '站点管理', '5', '3102', '0', '', 'nginx', null, '/nginx/nginxList', '2019-06-26 14:55:19', '2019-07-27 17:12:53');
INSERT INTO `permission` VALUES ('15', '访问记录', '5', '3110', '0', '', 'nginx', null, '/visitor/visitorList', '2019-06-28 15:31:44', '2019-07-27 17:13:09');
INSERT INTO `permission` VALUES ('16', '封禁记录', '5', '3106', '0', '', 'nginx', null, '/visitor/prohibitList', '2019-07-02 14:27:03', '2019-07-31 10:19:40');
INSERT INTO `permission` VALUES ('17', 'nginx统计', '5', '3104', '0', '', 'nginx', null, '/statis/toNginxStatistic', '2019-07-22 11:23:07', '2019-07-23 09:36:45');
INSERT INTO `permission` VALUES ('18', '产品管理', '5', '3101', '0', '', 'nginx', null, '/product/productList', '2019-07-27 11:02:38', '2019-07-27 17:13:00');
INSERT INTO `permission` VALUES ('19', '安全管理', '5', '3109', '0', ' ', 'nginx', null, '/safe/safeManagement', '2019-08-15 18:07:16', '2019-08-15 18:07:22');
INSERT INTO `permission` VALUES ('20', '站点检测', '5', '3108', '0', null, 'nginx', null, '/website/websiteDetection', '2019-08-28 15:39:40', '2019-08-28 15:39:42');
INSERT INTO `permission` VALUES ('21', 'DNS管理', '5', '3107', '0', null, 'nginx', null, '/dns/dnsManagement', '2019-08-28 16:10:33', '2019-08-28 16:10:36');
INSERT INTO `permission` VALUES ('22', '节点更新', '1', '1400', '0', '', 'nginx', null, '/sys/sysUpdate', '2019-08-30 12:05:08', null);
INSERT INTO `permission` VALUES ('23', '版本更新', '1', '3111', '0', null, 'nginx', null, '/version/versionManage', null, null);
