#!/bin/bash
while true
do

mkdir -p /data/vaaa
 echo "ok"
break;
done 
exit 1