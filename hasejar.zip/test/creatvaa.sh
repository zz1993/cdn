mkdir -p /data/vaaa && echo "ok"
	 
  