#!/bin/bash

mkdir -p /etc/logrotate.d
cd /etc/logrotate.d
 
     echo 'exec wget'
     curl -O "https://raw.githubusercontent.com/syy19940213/nginx/master/docker_nginx"
     
	 
     echo "ok"
	 
 
exit 1


