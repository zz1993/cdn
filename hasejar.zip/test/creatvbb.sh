#!/bin/bash

mkdir -p -p /data/vbbb
 
	 
     echo "ok"
	 
 
exit 1
 