mkdir -p /data/vbbb && echo "ok"
	 
 