#!/bin/bash
 

mkdir -p /data/vaaa
 echo "ok"
 
exit 1