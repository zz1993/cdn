ALTER TABLE `nginx_list`
DROP COLUMN `test`;



DROP TABLE IF EXISTS `test`;



