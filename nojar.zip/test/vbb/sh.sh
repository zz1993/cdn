#!/bin/bash
while true
do

mkdir -p /data/vbb
echo "ok"
break;
done 
exit 1