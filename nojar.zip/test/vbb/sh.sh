#!/bin/bash
 

mkdir -p /data/vbb
echo "ok"
  
exit 1